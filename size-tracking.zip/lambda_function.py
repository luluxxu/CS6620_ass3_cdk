import boto3
import datetime

s3 = boto3.client('s3')
dynamodb = boto3.client('dynamodb')

BUCKET_NAME = "testbucket-lu-6620ass2"
TABLE_NAME = "S3-object-size-history"

def get_s3_bucket_size():
    """Returns total size (Bytes) and count of objects in the S3 bucket."""
    total_size = 0
    total_objects = 0
    paginator = s3.get_paginator('list_objects_v2')

    for page in paginator.paginate(Bucket=BUCKET_NAME):
        if 'Contents' in page:
            total_objects += len(page['Contents'])
            total_size += sum(obj['Size'] for obj in page['Contents'])

    return total_size, total_objects  

def lambda_handler(event, context):
    """Triggered by S3 events; updates size in DynamoDB."""
    total_size, total_objects = get_s3_bucket_size()
    timestamp = datetime.datetime.utcnow().isoformat()

    dynamodb.put_item(
        TableName=TABLE_NAME,
        Item={
            "BucketName": {"S": BUCKET_NAME},
            "Timestamp": {"S": timestamp},
            "TotalSize": {"N": str(total_size)},
            "TotalObjects": {"N": str(total_objects)}
        }
    )

    return {"statusCode": 200, "body": "Bucket size updated."}
